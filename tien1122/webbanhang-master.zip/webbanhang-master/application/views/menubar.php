<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title></title>
	<script type="text/javascript" src="<?= base_url() ?>1.js"></script>
	<link rel="stylesheet" href="<?= base_url() ?>vendor/bootstrap.css">
	<link rel="stylesheet" href="<?= base_url() ?>vendor/font-awesome.css">
	<link rel="stylesheet" href="<?= base_url() ?>1.css">
	<title>Document</title>
</head>
<body>
		<nav class="navbar navbar-expand-md navbar-light bg-light">
        <a class="navbar-brand" href="#">Quyền Admin</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link active" href="<?= base_url() ?>index.php/quanao/denSuaThongTin">Chỉnh sửa dữ liệu <span class="sr-only">(current)</span></a>
      <a class="nav-item nav-link active" href="<?= base_url() ?>index.php/quanao/denSuaThongTin">Sửa banner <span class="sr-only">(current)</span></a>
      <a class="nav-item nav-link active" href="<?= base_url() ?>index.php/quanao/">Đưa về trang chủ <span class="sr-only">(current)</span></a>
     <a class="nav-item nav-link active" href="<?= base_url() ?>index.php/quanao/denSuaThongTin">Chỉnh sửa dữ liệu <span class="sr-only">(current)</span></a>
    </div>
  </div>
</nav>
	</div>
</body>
</html>