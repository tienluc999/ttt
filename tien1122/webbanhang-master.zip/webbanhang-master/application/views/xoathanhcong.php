<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="refresh" content="3; url=<?= base_url() ?>index.php/quanao/denSuaThongTin">
	<title>Thành công</title>
  	<script type="text/javascript" src="<?= base_url() ?>vendor/bootstrap.js"></script>	
	<script type="text/javascript" src="<?= base_url() ?>1.js"></script>
	<link rel="stylesheet" href="<?= base_url() ?>vendor/bootstrap.css">
	<link rel="stylesheet" href="<?= base_url() ?>vendor/font-awesome.css">
	<link rel="stylesheet" href="<?= base_url() ?>1.css">
	<title>Document</title>
</head>
<body>
	<br>
	<br>
	<br>
	<div class="alter alter-infor" role="alter">
		<strong>Bạn đã xóa thành công</strong>
	</div>
</body>
</html>